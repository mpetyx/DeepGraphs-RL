from distutils.core import setup
setup(name="RDFClosure",
      description="RDFClosure Library",
      version="5",
      author="Ivan Herman",
      author_email="ivan@ivan-herman.net",
	  maintainer="Ivan Herman",
	  maintainer_email="ivan@ivan-herman.net",
      packages=['RDFClosure'],
	  requires=['rdflib']
)

