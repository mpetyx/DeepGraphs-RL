

from ontospy.ontospy import *


o = Ontology("semanticbible.rdf")


o.printClassTree()